"""
Models weights:
https://storage.googleapis.com/narya-bucket-1/models/11_vs_11_easy_stochastic_v2
https://storage.googleapis.com/narya-bucket-1/models/11_vs_11_selfplay_last
https://storage.googleapis.com/narya-bucket-1/models/deep_homo_model.h5
https://storage.googleapis.com/narya-bucket-1/models/keypoint_detector.h5
https://storage.googleapis.com/narya-bucket-1/models/player_reid.pth
https://storage.googleapis.com/narya-bucket-1/models/player_tracker.params
https://storage.googleapis.com/narya-bucket-1/models/deep_homo_model_1.h5

"""
