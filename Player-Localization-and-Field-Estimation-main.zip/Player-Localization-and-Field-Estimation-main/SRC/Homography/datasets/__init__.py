"""
Datasets zip:
https://storage.googleapis.com/narya-bucket-1/dataset/homography_dataset.zip
https://storage.googleapis.com/narya-bucket-1/dataset/keypoints_dataset.zip
https://storage.googleapis.com/narya-bucket-1/dataset/tracking_dataset.zip

"""
